#!/bin/bash
while :
do
    echo "I <3 BOSH"
    sleep 1
done
